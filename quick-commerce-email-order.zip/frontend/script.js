const products = [
  {id:1,name:"Milk 1L",price:60,emoji:"🥛"},
  {id:2,name:"Bread",price:40,emoji:"🍞"},
  {id:3,name:"Biscuits",price:30,emoji:"🍪"},
  {id:4,name:"Cold Drink",price:50,emoji:"🥤"},
  {id:5,name:"Rice 5kg",price:350,emoji:"🍚"},
  {id:6,name:"Cooking Oil 1L",price:150,emoji:"🫗"}
];

let cart = JSON.parse(localStorage.getItem("cart") || "[]");

const productsEl = document.getElementById("products");
const cartItemsEl = document.getElementById("cartItems");
const totalEl = document.getElementById("total");
const cartCountEl = document.getElementById("cartCount");

function saveCart(){ localStorage.setItem("cart", JSON.stringify(cart)); }

function renderProducts(){
  productsEl.innerHTML = products.map(p => `
    <div class="product">
      <div class="emoji">${p.emoji}</div>
      <h3>${p.name}</h3>
      <div class="price">₹${p.price}</div>
      <button onclick="addToCart(${p.id})">Add to Cart</button>
    </div>
  `).join("");
}

function addToCart(id){
  const item = cart.find(x => x.id === id);
  if(item) item.qty++;
  else cart.push({id,qty:1});
  saveCart(); renderCart();
}

function changeQty(id, amount){
  const item = cart.find(x => x.id === id);
  if(!item) return;
  item.qty += amount;
  if(item.qty <= 0) cart = cart.filter(x => x.id !== id);
  saveCart(); renderCart();
}

function renderCart(){
  let total = 0, count = 0;
  if(cart.length === 0){
    cartItemsEl.innerHTML = "<p>Your cart is empty.</p>";
  } else {
    cartItemsEl.innerHTML = cart.map(item => {
      const p = products.find(x => x.id === item.id);
      const subtotal = p.price * item.qty;
      total += subtotal; count += item.qty;
      return `<div class="cart-row">
        <span>${p.emoji} ${p.name} × ${item.qty}</span>
        <span>₹${subtotal}
        <button onclick="changeQty(${p.id},1)">+</button>
        <button onclick="changeQty(${p.id},-1)">−</button></span>
      </div>`;
    }).join("");
  }
  totalEl.textContent = total;
  cartCountEl.textContent = count;
}

document.getElementById("cartBtn").onclick = () =>
  document.getElementById("checkout").scrollIntoView({behavior:"smooth"});

document.getElementById("orderForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  if(cart.length === 0){
    alert("Please add a product to cart.");
    return;
  }

  const customer = {
    name: document.getElementById("name").value.trim(),
    phone: document.getElementById("phone").value.trim(),
    address: document.getElementById("address").value.trim(),
    payment: document.getElementById("payment").value,
    items: cart.map(item => {
      const p = products.find(x => x.id === item.id);
      return {name:p.name, price:p.price, quantity:item.qty};
    }),
    total: Number(totalEl.textContent)
  };

  const message = document.getElementById("message");
  message.textContent = "Placing order...";

  try {
    const response = await fetch("http://localhost:3000/api/order", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(customer)
    });
    const data = await response.json();

    if(!response.ok) throw new Error(data.message || "Order failed");

    message.textContent = "Order placed successfully! Order ID: " + data.orderId;
    cart = [];
    saveCart();
    renderCart();
    e.target.reset();
  } catch(err) {
    message.textContent = "Order could not be sent. Start the backend and check your email settings.";
    console.error(err);
  }
});

renderProducts();
renderCart();
