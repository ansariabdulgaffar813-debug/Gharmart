require("dotenv").config();
const express = require("express");
const cors = require("cors");
const nodemailer = require("nodemailer");
const crypto = require("crypto");

const app = express();
app.use(cors());
app.use(express.json());

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

app.get("/", (req,res) => res.send("Quick Commerce API is running"));

app.post("/api/order", async (req,res) => {
  try {
    const {name, phone, address, payment, items, total} = req.body;

    if(!name || !phone || !address || !payment || !Array.isArray(items) || !items.length){
      return res.status(400).json({message:"Missing order details"});
    }

    const orderId = "QM-" + crypto.randomBytes(4).toString("hex").toUpperCase();

    const itemText = items.map((item, i) =>
      `${i+1}. ${item.name} × ${item.quantity} = ₹${item.price * item.quantity}`
    ).join("\n");

    const emailText = `
NEW QUICK COMMERCE ORDER
========================
Order ID: ${orderId}

CUSTOMER
Name: ${name}
Mobile: ${phone}
Address: ${address}
Payment: ${payment}

ITEMS
${itemText}

TOTAL: ₹${total}
`;

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: process.env.OWNER_EMAIL,
      subject: `New Order ${orderId} - Quick Commerce`,
      text: emailText
    });

    res.json({success:true, orderId});
  } catch(error) {
    console.error(error);
    res.status(500).json({message:"Email could not be sent"});
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
