QUICK COMMERCE - EMAIL ORDER VERSION

1. Install Node.js.
2. Open Terminal in backend folder.
3. Run: npm install
4. Copy .env.example to .env
5. Put your Gmail address in EMAIL_USER and OWNER_EMAIL.
6. Put a Gmail App Password in EMAIL_PASS.
7. Run: npm start
8. Open frontend/index.html in a browser.

IMPORTANT:
- Never publish your .env file.
- Do not put your Gmail password in frontend files.
- For production, host the frontend and backend on a server/hosting platform and change the API URL in frontend/script.js.
